Since we seeded our website with some fake data in the [last episode](http://watch-learn.com/video-tutorials/making-websites-october-cms-part-27-seeding-faker) it's time to search through that data. 

And we are going to do that using [SiteSearch plugin](https://octobercms.com/plugin/offline-sitesearch). Of course you can create your own custom search plugin if you want but for most needs this great plugin is going to be quite enough.

In this episode I'm going to show you how to search through your CMS pages, and also through your custom plugins, in our case it's going to be movies.